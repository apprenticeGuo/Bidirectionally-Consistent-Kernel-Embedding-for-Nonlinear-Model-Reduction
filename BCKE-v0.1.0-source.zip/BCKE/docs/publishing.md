# Publishing

Suggested repository: apprenticeGuo/BCKE.

Review the source, notebook, MIT notice and validation report. Create an empty
GitHub repository named BCKE, then run from this project directory:

~~~bash
git init -b main
git add .
git commit -m "Initial BCKE research software release"
git remote add origin https://github.com/apprenticeGuo/BCKE.git
git push -u origin main
~~~

Inspect existing repository/remotes first if present. Sign in through Git
Credential Manager when prompted. Do not store tokens in source or notebooks.
After CI passes, a versioned GitHub Release can be archived through Zenodo for a
software DOI. Add a dataset archive link when available.
