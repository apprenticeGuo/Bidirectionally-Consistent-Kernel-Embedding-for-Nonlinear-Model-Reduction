# Reproducibility

The synthetic example and tests need no flow data. Tests cover coordinate
constraints, the full-sample objective derivative, split isolation, base-model
save/load parity, and VTU conversion. docs/validation.json records actual checks
and observed dependency versions. Remote CI is not claimed until it runs.

The notebook retains scientific settings. configs/ records literal assignments
for inspection; the notebook is authoritative for derived/dataclass settings.

Base representation selection uses parameter-only full-state validation error.
Continuation selection is a later step. Debugging cells validate predictors on
coordinates from an already-fitted representation; their scores are conditional
on it, not independent end-to-end validation errors. Do not tune on final tests.

Full flow reproduction requires the original data, reference VTUs, correct
parameter labels, output times, software environment and predictor variant.
The automated workflow runs small numerical/data tests, not full
600-iteration flow experiments.

On the local Anaconda installation, mixed NumPy/PyTorch OpenMP runtimes caused
an abort before fitting. The tests passed with process-local
MKL_THREADING_LAYER=SEQUENTIAL, MKL_NUM_THREADS=1 and OMP_NUM_THREADS=1.
These settings were not written into the library or the system environment.
