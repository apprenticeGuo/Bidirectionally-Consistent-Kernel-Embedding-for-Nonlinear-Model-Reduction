# Provenance

The source is the supplied seven-cell notebook ending in ppmd_cell4.ipynb.
Hashes are recorded in source_manifest.json.

Packaging changes:
- Cell 1 definitions move into src/bcke/implementation.py.
- IPython display becomes optional for command-line use.
- The step loader default becomes data/step/vtu.
- Notebook Cell 1 becomes imports and configurable paths.
- Default data source becomes portable NPZ rather than a local module.
- Absolute workstation paths, outputs, execution counts and editor metadata are removed.
- Numerical definitions and scientific settings are retained.

The original notebook is untouched. Data, generated outputs and external
Diffusion.py are not redistributed. Packaging is not a claim that all paper and
notebook prediction variants are identical.
