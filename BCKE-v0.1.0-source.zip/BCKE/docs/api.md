# API

- BCKEFullSampleConfig: configuration with n_folds=0.
- BCKEFullSampleProblem: fitting-state reconstruction objective and kernel maps.
- run_bcke_experiment_full_sample: representation/predictor selection and refitting.
- LocalAffineDMDExtrapolator: fixed local affine continuation.
- LinearCoordinateVaryingM: varying linear continuation.
- LocalSecantLifting: alias for LocalLatentDecoderContinuation.
- DirectPolynomialZContinuation: direct local/global polynomial prediction.
- TrendKernelResidualZContinuation: trend-plus-kernel coordinate prediction.
- fit_pod_rbf_reference and fit_ppmd_reference: supplied comparison variants.
- plot_and_export_flow_method_comparison: field/error panels and VTUs.

Definitions remain in implementation.py to keep the extraction auditable.
Historical identifiers are retained, including some containing decoder.
The mathematical terminology is reduction and lifting.

save_bcke_results and predict_saved_bcke save/load the base kernel predictor.
That base NPZ is not the final continuation predictor. The notebook separately
saves continuation arrays and settings.
