# Contributing

Install .[experiments,dev] and run python -m pytest -q.
Explain numerical changes with comparisons on fixed fitting/validation/test cases.
Keep datasets and notebook outputs out of commits. Report software versions,
settings and a small reproducible example with bugs.
Contributions are accepted under the MIT License.
