"""Convert an explicit ordered VTU manifest into a portable NPZ dataset."""
import argparse
import csv
from pathlib import Path
import numpy as np

def convert_manifest(manifest, output, component="u", field="Velocity"):
    import meshio
    if component not in ("u", "v", "uv"):
        raise ValueError("component must be u, v, or uv")
    manifest, output = Path(manifest), Path(output)
    with manifest.open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if not rows or not {"parameter", "path"}.issubset(rows[0]):
        raise ValueError("Manifest needs parameter,path columns and at least one row.")
    mu = np.asarray([float(row["parameter"]) for row in rows], dtype=np.float64)
    if not np.isfinite(mu).all() or np.any(np.diff(mu) <= 0):
        raise ValueError("Parameters must be finite and strictly increasing in file order.")
    states, points, cells = [], None, None
    for row in rows:
        path = Path(row["path"])
        mesh = meshio.read(path if path.is_absolute() else manifest.parent / path)
        if points is None:
            points, cells = mesh.points.copy(), [(c.type, c.data.copy()) for c in mesh.cells]
        elif (mesh.points.shape != points.shape or not np.allclose(mesh.points, points)
              or len(mesh.cells) != len(cells)
              or any(c.type != typ or not np.array_equal(c.data, data)
                     for c, (typ, data) in zip(mesh.cells, cells))):
            raise ValueError("VTU geometry or node ordering differs between cases.")
        if field not in mesh.point_data:
            raise ValueError(f"Missing point field {field!r} in {path}.")
        values = np.asarray(mesh.point_data[field], dtype=np.float64)
        if values.ndim != 2 or values.shape[1] < 2:
            raise ValueError("Velocity must have at least two components per point.")
        state = values[:, 0] if component == "u" else values[:, 1]
        if component == "uv":
            state = np.r_[values[:, 0], values[:, 1]]
        if not np.isfinite(state).all():
            raise ValueError(f"Nonfinite state values in {path}.")
        states.append(state)
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(output, states=np.vstack(states), parameters=mu[:, None])
    return output

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--component", choices=("u", "v", "uv"), default="u")
    parser.add_argument("--field", default="Velocity")
    args = parser.parse_args()
    print(convert_manifest(args.manifest, args.output, args.component, args.field))

if __name__ == "__main__":
    main()
