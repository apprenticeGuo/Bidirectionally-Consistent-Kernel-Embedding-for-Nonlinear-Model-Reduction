"""Small executable example independent of the flow datasets."""
import argparse
import numpy as np
import torch
from .implementation import (BCKEFullSampleConfig, PredictionConfig,
    run_bcke_experiment_full_sample, synthetic_bcke_data, save_bcke_results)

def run_smoke(iterations=6, audit=False):
    torch.set_num_threads(1)
    states, mu, weights = synthetic_bcke_data(n=24, nh=14, seed=42)
    cfg = BCKEFullSampleConfig(p=2, d=2, max_total_dimension=4,
        k_start=4, verbose_every=0, sigma_lambda_factor=1.0)
    prediction = PredictionConfig(sigma_factors=(1.0,), ridges=(1e-4,),
        block_pairs=(), correction_nus=(1.0,), correction_max_iterations=2)
    result = run_bcke_experiment_full_sample(states, mu, weights, cfg,
        {}, prediction, n_train=14, n_final=18, n_total=24,
        max_iterations=iterations, audit=audit)
    assert np.isfinite(result["prediction_all"]).all()
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--iterations", type=int, default=6)
    parser.add_argument("--output", default="outputs/synthetic")
    args = parser.parse_args()
    result = run_smoke(args.iterations)
    out = save_bcke_results(result, args.output)
    print(result["metrics"].to_string(index=False))
    print("Synthetic results saved to:", out)
    print("This short run checks execution, not publication accuracy.")

if __name__ == "__main__":
    main()
