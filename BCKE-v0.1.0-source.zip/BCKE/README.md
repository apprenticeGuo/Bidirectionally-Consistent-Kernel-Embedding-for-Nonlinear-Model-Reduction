# BCKE

**Bidirectionally Consistent Kernel Embedding for Nonlinear Model Reduction**

BCKE constructs a linear representation and a nonlinear residual representation.
Residual coordinates are optimized using reconstruction, composition, and geometric
consistency in both directions. Regularized kernel fits determine the reduction
and lifting maps for each coordinate matrix. PyTorch provides linear algebra and
automatic differentiation.

This repository packages the supplied cylinder/step research notebook. It includes
BCKE, the supplied POD+RBF and PPMD comparison variants, parameter prediction,
field/error plots, and VTU export. Numerical definitions and scientific settings
are retained; workstation paths and saved notebook outputs are removed.

## Install

Use Python 3.10 or newer in a fresh virtual environment.

~~~bash
python -m venv .venv
# Windows: .venv/Scripts/activate
# Linux/macOS: source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[experiments,dev]"
~~~

For only the numerical core, use python -m pip install -e .
CUDA requires a compatible PyTorch installation. Defaults use CPU and float64.
The locally tested numerical versions are recorded in requirements-observed.txt;
that file also installs the experiment extra. A fresh dependency resolution is
not claimed to have been tested.

## Quick start without flow data

~~~bash
python -m bcke.smoke --iterations 6 --output outputs/synthetic
python -m pytest -q
~~~

The deterministic synthetic example checks fitting, prediction and saving.
A short optimization run is not a publication accuracy result.

~~~python
from bcke import BCKEFullSampleConfig, run_bcke_experiment_full_sample
~~~

See [API notes](docs/api.md) for the representation and predictor classes.

## Flow experiments

1. Install the experiments extra.
2. Place cylinder.npz and step.npz in data/, following [the data format](data/README.md).
3. Launch jupyter lab from the repository root and open
   [notebooks/cylinder_step.ipynb](notebooks/cylinder_step.ipynb).
4. Run Cell 1, then the relevant experiment and plotting cells.

| Cell | Purpose | Requires |
|---|---|---|
| 1 | Imports and data/output locations | Installed package |
| 2 | Cylinder fitting and three-method comparison | Cell 1 and cylinder data |
| 3 | Cylinder fields, errors and VTUs | Cells 1-2 and reference VTUs |
| 4 | Independent cylinder prediction settings | Cells 1-2 |
| 5 | Step fitting and three-method comparison | Cell 1 and step data |
| 6 | Step fields, errors and VTUs | Cells 1 and 5 and reference VTUs |
| 7 | Independent step prediction settings | Cells 1 and 5 |

Set BCKE_DATA_DIR, BCKE_OUTPUT_DIR, BCKE_CYLINDER_VTU_ROOT or
BCKE_STEP_VTU_ROOT for other locations. Defaults are project relative.
The legacy ppmd cylinder loader still needs external Diffusion.py;
the portable NPZ route is the default and does not require that file.

Defaults use 80 fitting cases for selection, ten validation cases, and ten test
cases, then refit on the first 90. BCKE uses 7+5 coordinates, PPMD uses 8+4,
and POD+RBF uses 12. The full-sample representation has no folds.

## Prediction variants

The supplied notebook uses a **varying matrix** for linear continuation,
direct local polynomial prediction for nonlinear coordinates, and local secant
lifting. Independent cells also offer trend-plus-kernel prediction.
A fixed local affine predictor is available separately. Packaging preserves the
supplied choice; match the implementation to the manuscript formulas.

The supplied PPMD forecasting variant directly fits the high dimensional residual
from the parameter outside the fitting interval. Its diffusion coordinate count
does not imply that this forecast operates exclusively in reduced coordinates.
Reconstruction and prediction retain their separate source settings.

## Layout

~~~text
src/bcke/       Numerical implementation, API, example and data converter
notebooks/      Seven-cell flow notebook with cleared outputs
configs/        Literal settings from the original experiment cells
examples/       Small executable example
scripts/        Repository checks
tests/          Numerical and data interface tests
data/           Dataset instructions and manifest example
docs/           API, provenance, reproducibility and publishing notes
.github/        Automated test and build workflow
~~~

Flow datasets and generated figures are not bundled. See
[reproducibility](docs/reproducibility.md) and the [validation report](docs/validation.json)
for checks actually run. No new flow accuracy measurements are claimed.

## Citation and license

Use [CITATION.cff](CITATION.cff) to cite the software. A paper DOI can be added when
available. The software uses the [MIT License](LICENSE). Dependencies retain their
own licenses.
