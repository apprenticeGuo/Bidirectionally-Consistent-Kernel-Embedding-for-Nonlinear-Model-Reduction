import numpy as np
import pytest
from bcke import (BCKEFullSampleConfig, validate_bcke_config,
    directional_derivative_check_full_sample, save_bcke_results, predict_saved_bcke)
from bcke.smoke import run_smoke

@pytest.fixture(scope="module")
def result():
    return run_smoke(iterations=4)

def test_full_sample_geometry_and_split(result):
    Z = result["problem"].Z_np
    np.testing.assert_allclose(Z.sum(axis=1), 0, atol=1e-10)
    np.testing.assert_allclose(Z @ Z.T, len(result["final_fit_indices"]) * np.eye(2), atol=1e-9)
    assert set(result["final_fit_indices"]).isdisjoint(result["test_indices"])
    assert result["protocol"]["reconstruction_folds"] == 0
    assert np.isfinite(result["prediction_all"]).all()

def test_gradient_of_full_sample_objective(result):
    report = directional_derivative_check_full_sample(result["problem"], tolerance=5e-4)
    assert not report.empty

def test_saved_kernel_predictor_round_trip(result, tmp_path):
    output = save_bcke_results(result, tmp_path)
    restored = predict_saved_bcke(output / "parameter_model.npz", result["parameters"])
    np.testing.assert_allclose(restored, result["prediction_all"], rtol=1e-10, atol=1e-10)

def test_invalid_core_weights_are_rejected():
    with pytest.raises(ValueError, match="Core weights"):
        validate_bcke_config(BCKEFullSampleConfig(alpha_x=0.0))
