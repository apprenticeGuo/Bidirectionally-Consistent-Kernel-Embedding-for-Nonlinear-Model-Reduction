import numpy as np
import pytest
from bcke.data import convert_manifest

def test_vtu_conversion(tmp_path):
    meshio = pytest.importorskip("meshio")
    points = np.array([[0., 0., 0.], [1., 0., 0.], [0., 1., 0.]])
    for k in (1, 2):
        mesh = meshio.Mesh(points, [("triangle", [[0, 1, 2]])],
            point_data={"Velocity": np.column_stack([np.arange(3) + k, np.zeros(3), np.zeros(3)])})
        mesh.write(tmp_path / f"{k}.vtu")
    manifest = tmp_path / "cases.csv"
    manifest.write_text("parameter,path\n0.1,1.vtu\n0.2,2.vtu\n")
    output = convert_manifest(manifest, tmp_path / "data.npz")
    with np.load(output, allow_pickle=False) as data:
        np.testing.assert_allclose(data["parameters"].ravel(), [0.1, 0.2])
        np.testing.assert_allclose(data["states"], [[1, 2, 3], [2, 3, 4]])
    manifest.write_text("parameter,path\n0.2,1.vtu\n0.1,2.vtu\n")
    with pytest.raises(ValueError, match="strictly increasing"):
        convert_manifest(manifest, tmp_path / "bad.npz")
