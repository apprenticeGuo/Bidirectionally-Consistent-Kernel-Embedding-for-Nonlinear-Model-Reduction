# Changelog

## 0.1.0

- Package the supplied BCKE numerical implementation with its comparison methods.
- Provide a portable seven-cell cylinder/step notebook and explicit data interface.
- Add synthetic example, numerical tests, MIT license and software citation.
- Document predictor variants, software versions and reproduction limits.
