from bcke.smoke import main

if __name__ == "__main__":
    main()
