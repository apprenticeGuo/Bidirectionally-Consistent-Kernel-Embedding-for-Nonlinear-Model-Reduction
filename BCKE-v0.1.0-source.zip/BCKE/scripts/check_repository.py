"""Check syntax, notebook outputs and portable paths."""
import ast,json,re
from pathlib import Path
root = Path(__file__).resolve().parents[1]
for p in (root / "src").rglob("*.py"):
    ast.parse(p.read_text(encoding="utf-8"))
nb = json.loads((root / "notebooks/cylinder_step.ipynb").read_text(encoding="utf-8"))
assert len(nb["cells"]) == 7
for cell in nb["cells"]:
    assert not cell.get("outputs") and cell.get("execution_count") is None
    source = "".join(cell["source"])
    ast.parse(source)
    assert not re.search(r"[A-Za-z]:[\\/]", source), "Workstation path in notebook"
print("Repository syntax and notebook hygiene checks passed.")
