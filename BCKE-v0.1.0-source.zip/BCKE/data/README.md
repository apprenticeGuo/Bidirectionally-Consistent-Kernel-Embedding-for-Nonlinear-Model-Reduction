# Dataset interface

Supply states of shape (N, n_dofs) and parameters of shape (N, 1) in an NPZ file.
Optional entries are weights (diagonal vector or SPD matrix) and case_ids.
The notebook also supports a separate weights file.

Each row is one physical parameter case, using the same spatial node order and
observation definition. Supplied VTU loaders read one stored velocity field per
parameter, not a stacked time trajectory. Default component: horizontal velocity.
Default norm: identity weights. Use consistent physical output times.
Labels must exactly match snapshot order. A viscosity grid is not a replacement
for labels of a newly generated Reynolds-number dataset.

Legacy cylinder labels: np.linspace(0.2e-4, 10.1e-4, 100).
Legacy step labels: np.arange(1, 101) * 2e-5.
These are defaults, not values inferred from filenames. The continuation examples
expect ordered, uniformly spaced scalar parameters.

## VTU conversion

Create a CSV with parameter,path columns in increasing parameter order.
Relative paths are resolved relative to that CSV. Then run:

~~~bash
python -m bcke.data --manifest data/cylinder_manifest.csv --output data/cylinder.npz --component u
~~~

The converter checks finite values, parameter order and mesh/node consistency.
The point field defaults to Velocity; change --field if needed.
See manifest.example.csv.

Reference VTUs are also needed for off-grid field/error plots. They are used for
evaluation and geometry, not parameter predictor fitting. The manifest is a format
illustration and does not reference bundled data.

No dataset URL has been supplied. Add an archive/DOI before claiming public
reproduction of the flow figures. Large simulation data should not be committed.
